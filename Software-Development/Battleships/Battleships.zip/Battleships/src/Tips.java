
public class Tips {

	/**
	 * Displays tips
	 */
	public void displayTips() {
		System.out.println("Welcome to Battleships!\n");
		System.out.println("If you want to save game enter: save");
		System.out.println("If you want to quit the game enter: quit");
		System.out.println("If you want to confirm this enter: yes");
		System.out.println("\nThis game was made by:");
		System.out.println("Isaac Lowry\n");

	}
}
