import java.io.Serializable;

public class Grid implements Serializable {

	/**
	 * Creates a 2D array for the board
	 */
	private int[][] board;
	
	/**
	 * Checks if a ship can be placed on the board
	 * @param c
	 * @return returns if ship placement was successful
	 */
	public boolean placeShip(int[][] c) {
        for(int[] i : c) {
            //Checks if x or y is less than zero
            //Checks if x or y is greater than the boundaries
            //Checks if board state at x and y is equal to 1
            //1 means that there is a ship
            //If any of the checks pass that means that the ship cannot be placed there
            if(i[0] < 0  || i[1] < 0 || i[0] >= board[0].length || i[1] >= board.length || board[i[1]][i[0]] == 1)
            {
                return false;
            }
        }
        //Sets board state at x and y to 1
        //Which means that the ship is placed
        for(int[] i : c){
            board[i[1]][i[0]] = 1;
        }
        
        return true;
    }

    
	/**
	 * Prints out the board
	 * @param score  user score to be printed out
	 */
	public void displayBoard(String score) {
        System.out.println("\n           RANK: "+score+"\n");

        System.out.print("  ");
        char c ='a';
        //loops through alphabet and prints out corresponding letter
        for(int s = 0; s < 9; s++) {
        	
        	System.out.print(" "+c+" ");
        	c++;
        	
        }
        //loops through rows
        for(int s = 0; s < 9; s++){
            //prints out row number
            System.out.print("\n"+(s+1)+" ");
            //loop through columns
            for(int s2 = 0; s2 < 9; s2++) {
                //if ship has been hit [x] is printed
                if(board[s][s2] == 3) {
                    System.out.print("|X|");
                //if ship has been missed [o] is printed
                }else if(board[s][s2] == 2) {
                	System.out.print("|O|");
                }
                //if none of the above qualify [ ] is printed
                else {
                	System.out.print("| |");
                }
            }
        }
    }
	
	/**
	 * Checks whether a ship has been hit or not
	 * @param x Board's X coordinate
	 * @param y Board's Y coordinate
	 * @return returns if setting the cell state was successful
	 */
	public boolean setState(int x, int y) {
	    //1 is subtracted from both x and y because arrays start from 0 and user input 1, 1
		x--;
		y--;
		//checks if x and y is is not out of bounds
        //if all of the checks pass that means that the user input was correct
        if(x >= 0  && y >= 0 && x <= board[0].length && y <= board.length) {
        	//check if ship exists at x and y and if ship has been already hit at x and y
        	if (board[y][x] == 1 || board[y][x] == 3) {
    			board[y][x] = 3;
    			return true;
    		}
    		//if above fails then it means an empty cell has been hit
    		else {
    			board[y][x] = 2;
    			return false;
    		}
        }
        return false;
	}
	
	/**
	 * Sets  board size to 9 by 9
	 */
	Grid() {
		board = new int[9][9];
	}
}
