import java.io.Serializable;

public class Ship implements Serializable {

	/**
	 * Creates 2d array
	 */
	private int[][] sc;
	/**
	 * Creates an integer and sets it to 0
	 */
	private int health = 0;
	/**
	 * Type name field
	 */
	private String name;
	
	/**
	 * Checks if a ship has been destroyed
	 * @return returns if ship destruction was successful
	 */
	public boolean shipcheck() {
		health--;
		//checks if ships health is less than or equal to zero
		if(health <= 0) {
			return true;
		}
		return false;
	}
	
	/**
	 * Creates a 2D array of integers using variables
	 * @param t ship's coordinates y - length, x - coordinates of each tile
	 * @param h ship's health which is also equal to size
	 * @param s sip's name
	 */
	Ship(int[][] t, int h, String s) {
		sc = t;
		health = h;
		name = s;
	}

	/**
	 * Returns a 2D array
	 * @return returns ships coordinates
	 */
	public int[][] getSc() {
		return sc;
	}

	/**
	 * Gets ship name
	 * @return ship name
	 */
	public String getName() {
		return name;
	}
}
