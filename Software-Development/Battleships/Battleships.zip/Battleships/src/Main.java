
public class Main {

	/**
	 * Main method
	 * @param args Main method arguments
	 */
	public static void main(String[] args) {
		Menu menu1 = new Menu();
		menu1.processUserChoices();
	}

}
