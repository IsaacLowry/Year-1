import java.io.Serializable;
import java.util.Random;

public class Player implements Serializable {

	/**
	 * New grid object created
	 */
	private Grid grid = new Grid();
	/**
	 * New ship array object created
	 */
	Ship[] shipArray = new Ship[10];
	/**
	 * Creates an integer and sets it to 9
	 */
	int shipCount = 9;
	/**
	 * Creates a String and sets it to "F"
	 */
	String score = "F";
	/**
	 * Creates an integer and sets it to 0
	 */
	int succHits = 0;
	/**
	 * Creates an integer and sets it to 0
	 */
	int missedHits = 0;



	/**
	 * Generates ships randomly on the grid 
	 */
	public void shipGen() {
	    //initialising an array with all the ship sizes for easy tracking
		int[] ships = new int[]{4, 3, 3, 2, 2, 2, 1, 1, 1};
	    //initialising an array with all the ship names for easy tracking
		String[] shipNames = {"Battleship", "Cruiser", "Cruiser", "Destroyer", "Destroyer", "Destroyer", "Submarine", "Submarine", "Submarine"};
		Random numGen = new Random();

		for (int i=0; i<ships.length; i++)
		{
		    //infinite loop to keep trying until placement is correct
			while(true)
			{
				//Creating an array to store coordinates
				//both array elements are populated with random values between 0 and 8
				int[] ref1 = new int[2];
				ref1[0] = numGen.nextInt(9);
				ref1[1] = numGen.nextInt(9);
				//Generating random value between 0 and 1 for orientation
				//0 - horizontal
				//1 - vertical
				int or = numGen.nextInt(2);

				//Initialising a 2D array to store ships length and each cells coordinates
				int[][] ref2 = new int[ships[i]][2];

				//if position is horizontal
				if(or == 0){
					for (int r=0; r<ships[i]; r++)
					{
					    //y coordinate stays the same
						ref2[r][0] += ref1[0]-1;
						//x coordinate is extended by r for every cell
						ref2[r][1] += ref1[1]+r-1;
					}
					
				}
				//passes when position is vertical
				else {
					for (int r=0; r<ships[i]; r++)
					{
						//y coordinate is extended by r for every cell
						ref2[r][0] += ref1[1]+r-1;
						//x stays the same
						ref2[r][1] += ref1[0]-1;
					}
				}
				//if ship placement is successful
				if(grid.placeShip(ref2)) {
					//new ship object is created
					Ship ship = new Ship(ref2, ships[i], shipNames[i]);
					//ship object pushed to the ship array
					shipArray[i] = ship;
					break;
				}
			}
		}
	}

	/**
	 * Determines rank based on the score
	 */
	public void calculateScore() {
	    //Temporary value to keep score
		//one hit is worth 10 points
		//one miss deducts points by one
		int tmpScore = succHits * 10 - missedHits;
		if(tmpScore <= 30) {
			score = "F";
		}else if(tmpScore <= 60){
			score = "E";
		}else if(tmpScore <= 90) {
			score = "D";
		}else if(tmpScore <= 120){
			score = "C";
		}else if(tmpScore <= 150) {
			score = "B";
		}else{
			score = "A";
		}
	}

	/**
	 * @return returns grid object
	 */
	public Grid getGrid() {
		return grid;
	}
}
