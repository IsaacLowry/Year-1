import java.io.*;
import java.util.Scanner;

public class Menu {

	/**
	 * New game object created
	 */
	private static Game game = new Game();
	/**
	 * New tips object created
	 */
	private static Tips tips = new Tips();
	
	/**
	 * Displays Menu
	 */
	public void displayMenu () {
        System.out.println("__________         __    __  .__                .__    .__              ");
        System.out.println("\\______   \\_____ _/  |__/  |_|  |   ____   _____|  |__ |__|_____  ______");
        System.out.println(" |    |  _/\\__  \\\\   __\\   __\\  | _/ __ \\ /  ___/  |  \\|  \\____ \\/  ___/");
        System.out.println(" |    |   \\ / __ \\|  |  |  | |  |_\\  ___/ \\___ \\|   Y  \\  |  |_> >___ \\ ");
        System.out.println(" |______  /(____  /__|  |__| |____/\\___  >____  >___|  /__|   __/____  >");
        System.out.println("        \\/      \\/                     \\/     \\/     \\/   |__|       \\/ ");

		
        System.out.println("\nWelcome to Battleships!\n");
        System.out.println("1 - Start Game");
        System.out.println("2 - Load Game");
        System.out.println("3 - Tips");
        System.out.println("0 - Exit");
 
    }
	
    /**
     * Calls displayMenu
     * Processes user input and calls the function associated with the input
     */
    public void processUserChoices () {
      
        boolean exit = false;
        Scanner s1 = new Scanner(System.in);
     
       
        do {
        displayMenu();
        int input = s1.nextInt();
        s1.nextLine();

           
        if (input == 0) {
            
            exit = true;
            break;
        }
       
        else if (input == 1) {
            game.newGame();
            game.gameLoop();
        }	
       
        else if (input == 2) {
            loadGame();
            game.gameLoop();
        }
        
        else if (input == 3) {
        	tips.displayTips();
        }
        
        else {
            System.out.println("An invalid option was selected!");
        }
        }while(!exit);
    }

    /**
     * Saves the game progress to an output ".txt" file for loading
     */
    static void saveGame() {
        try {
            FileOutputStream outputFile = new FileOutputStream("./progress.txt");
            ObjectOutputStream outputStream = new ObjectOutputStream(outputFile);
            outputStream.writeObject(game);
            outputStream.close();
            outputFile.close();
            System.out.println("Game has been saved!");//
        }catch (IOException e){
            System.out.printf("\nError has occurred while saving\n%s\n", e);
        }
    }

    /**
     * Loads the output save file of game progress
     */
    private static void loadGame() {
        try{
            FileInputStream inputFile = new FileInputStream("./progress.txt");
            ObjectInputStream inputStream = new ObjectInputStream(inputFile);
            game = (Game) inputStream.readObject();
            inputStream.close();
            inputFile.close();
        } catch (IOException e){
            System.out.printf("\nError has occurred while opening save file!\n%s\n");
        } catch (ClassNotFoundException e) {
            System.out.println("Game class not found!\n");
        }
    }

}
