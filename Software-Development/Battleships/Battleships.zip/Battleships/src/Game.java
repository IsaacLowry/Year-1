import java.io.Serializable;
import java.util.Scanner;

public class Game implements Serializable{

	/**
	 * New player object created
	 */
	Player player = new Player();
	/**
	 * Creates boolean of game progress
	 */
	boolean gameProgress = true;

	/**
	 * Creates a new game
	 */
	public void newGame() {
		player.shipGen();
		System.out.println("\n\nShips have been generated");
	}
	
	/**
	 * Creates a loop determining game progress
	 */
	public void gameLoop() {
		int x;
		int y;
		Ship[] ships = player.shipArray;

		player.getGrid().displayBoard(player.score);
		while(gameProgress){
			while(true) {

				System.out.println("\nChoose a co-ordinate to fire at!");
				Scanner s1 = new Scanner(System.in);
				String input = s1.nextLine();

				if(input.equals("save")){
					Menu.saveGame();
					continue;
				}
				if(input.equals("quit")){
					System.out.println("\nAre you sure you want to quit?\n");
					if(s1.nextLine().equals("yes")){
						Menu.saveGame();
						return;
					}else{
						continue;
					}
				}


				if(input.length() != 2) {
					System.out.println("Wrong input");
					continue;
				}

				if(!Character.isLetter(input.charAt(0))) {
					System.out.println("Wrong input");
					continue;
				}

				boolean hasLowerCase = !input.equals(input.toUpperCase());

				if(!hasLowerCase) {
					System.out.println("Only enter lower case letters!");
					continue;
				}

				try {
					y = Integer.parseInt(Character.toString(input.charAt(1)));
					x = input.charAt(0)-'a'+1;
				}catch(Exception e) {
					System.out.println(e);
					System.out.println("Wrong input");
					continue;
				}
				break;
			}
			if(player.getGrid().setState(x, y)) {
				//Label that is used to break ouf of the nested for loop
				outer:
				//Goes trough the ship array
				for(int it  = 0; it < ships.length - 1; it++) {
					//Gets ships coordinates
					int[][] coords = ships[it].getSc();
					//Goes through the ship coordinates
					for(int itt = 0; itt < coords.length; itt++) {
						//Checks if the ship coordinates match input coordinates
						if(coords[itt][0] == x-1 && coords[itt][1] == y-1) {
						    //if coordinates match shipcheck() is invoked to reduce ships health
							//shipCheck() returns false until the ship is destroyed
							if(ships[it].shipcheck()){
								//reduces ship count by one
								player.shipCount--;
								//adds to successful hits plus one
								player.succHits++;
								player.calculateScore();
								//Displays the board
								player.getGrid().displayBoard(player.score);
								System.out.println("\n\nYou have destroyed the enemy's "+ships[it].getName()+"!\n");
								//Checks if all of the ships are destroyed
								if(player.shipCount <= 0) {
									System.out.println("\nYou have won the game!");
									//sets gameProgress flag to false to break the infinite loop
									gameProgress = false;
									System.out.println("\nYour RANK: "+player.score+"\n");
								}
							//Passes when ship is hit but not destroyed
							}else{
								player.succHits++;
								player.calculateScore();
								player.getGrid().displayBoard(player.score);
								System.out.println("\n\nYou have hit a ship, strike again!");
							}
							break outer;
						}
					}
				}
			}
			//Passes when the ship is missed
			else {
				player.calculateScore();
				player.getGrid().displayBoard(player.score);
				System.out.println("\n\nYou have missed");
				player.missedHits++;
			}


		}
	}
}
